<?php
/**
 * Pure PHP WordPress API Integration
 * Simple routing without framework dependencies
 */

// Load configuration
require_once __DIR__ . '/config.php';

// Start session
session_start();

// Load helper functions
require_once __DIR__ . '/includes/functions.php';

// Load API wrapper
require_once __DIR__ . '/includes/api.php';

// Improved Routing for XAMPP
$request_uri = $_SERVER['REQUEST_URI'];
$script_name = $_SERVER['SCRIPT_NAME']; // e.g. /ci4-wordpress-apis/index.php

// Find the path after index.php or after the project folder
if (strpos($request_uri, $script_name) === 0) {
    $path = substr($request_uri, strlen($script_name));
} else {
    $project_folder = dirname($script_name);
    $path = substr($request_uri, strlen($project_folder));
}

// Strip query string
$path = parse_url($path, PHP_URL_PATH);
$path = trim($path, '/');

// Route handling
switch ($path) {
    case '':
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/controllers/login_handler.php';
        } else {
            require __DIR__ . '/views/login.php';
        }
        break;

    case 'posts':
        require_auth();
        require __DIR__ . '/controllers/list_posts.php';
        break;

    case 'create-post':
        require_auth();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/controllers/create_post_handler.php';
        } else {
            require __DIR__ . '/controllers/create_post.php';
        }
        break;

    case (preg_match('/^update-post\/(\d+)$/', $path, $matches) ? true : false):
        require_auth();
        $post_id = $matches[1];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/controllers/update_post_handler.php';
        } else {
            require __DIR__ . '/controllers/update_post.php';
        }
        break;

    case (preg_match('/^delete-post\/(\d+)$/', $path, $matches) ? true : false):
        require_auth();
        $post_id = $matches[1];
        require __DIR__ . '/controllers/delete_post.php';
        break;

    case 'logout':
        session_destroy();
        redirect('login');
        break;

    default:
        http_response_code(404);
        echo "404 - Page Not Found";
        break;
}
