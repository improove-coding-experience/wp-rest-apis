# ✅ Setup Checklist - Pure PHP WordPress API App

## 📋 Pre-Flight Checklist

Use this checklist to ensure everything is set up correctly.

### 1. ✅ WordPress Configuration

- [ ] WordPress is installed and running
- [ ] JWT Authentication plugin is installed
- [ ] JWT_AUTH_SECRET_KEY is set in wp-config.php
- [ ] JWT_AUTH_CORS_ENABLE is set to true in wp-config.php
- [ ] WordPress .htaccess has Authorization header rule
- [ ] Can access WordPress REST API at: `http://your-site.com/wp-json/`

### 2. ✅ PHP Configuration

- [ ] PHP 7.4 or higher is installed
- [ ] cURL extension is enabled
- [ ] Sessions are enabled
- [ ] File upload is enabled
- [ ] upload_max_filesize is at least 10M
- [ ] post_max_size is at least 10M

### 3. ✅ Apache Configuration

- [ ] Apache is installed and running
- [ ] mod_rewrite is enabled
- [ ] .htaccess files are allowed (AllowOverride All)
- [ ] Can access: `http://localhost/ci4-wordpress-apis/`

### 4. ✅ Application Files

- [ ] index.php exists in root
- [ ] config.php exists in root
- [ ] .htaccess exists in root
- [ ] includes/ folder exists with 2 files
- [ ] controllers/ folder exists with 7 files
- [ ] views/ folder exists with 4 files
- [ ] assets/ folder exists with style.css

### 5. ✅ Configuration Updates

- [ ] Updated WP_API_BASE_URL in config.php
- [ ] Updated APP_BASE_URL in config.php
- [ ] Updated RewriteBase in .htaccess (if needed)

### 6. ✅ File Permissions (Linux/Mac only)

- [ ] All files are readable (chmod 644)
- [ ] All directories are executable (chmod 755)
- [ ] index.php is executable

### 7. ✅ Testing

- [ ] Can access login page: `/login`
- [ ] Can login with WordPress credentials
- [ ] Can see posts list: `/posts`
- [ ] Can create a new post
- [ ] Can upload featured image
- [ ] Can edit a post
- [ ] Can delete a post
- [ ] Can logout

## 🔧 Quick Tests

### Test 1: Apache & PHP

```bash
# Check PHP version
php -v

# Check if cURL is enabled
php -m | grep curl

# Check if Apache is running
# Windows:
httpd -v

# Linux:
apache2 -v
```

### Test 2: mod_rewrite

```bash
# Linux/Mac:
apache2ctl -M | grep rewrite

# Windows:
httpd -M | findstr rewrite
```

### Test 3: WordPress API

Visit in browser:

```
http://localhost/wp-rest-apis/wp-json/
```

Should show JSON response.

### Test 4: JWT Authentication

```bash
curl -X POST http://localhost/wp-rest-apis/wp-json/jwt-auth/v1/token \
  -H "Content-Type: application/json" \
  -d '{"username":"your-username","password":"your-password"}'
```

Should return a token.

### Test 5: Application Access

Visit in browser:

```
http://localhost/ci4-wordpress-apis/
```

Should show login page.

## 🐛 Troubleshooting Checklist

### Issue: 404 on all pages

- [ ] Check if mod_rewrite is enabled
- [ ] Check if .htaccess exists
- [ ] Check RewriteBase in .htaccess
- [ ] Check Apache AllowOverride setting

### Issue: Login fails

- [ ] Check WordPress JWT plugin is active
- [ ] Check JWT_AUTH_SECRET_KEY in wp-config.php
- [ ] Check WP_API_BASE_URL in config.php
- [ ] Check WordPress .htaccess Authorization rule
- [ ] Test JWT endpoint directly (see Test 4 above)

### Issue: Images won't upload

- [ ] Check PHP upload_max_filesize
- [ ] Check PHP post_max_size
- [ ] Check WordPress media upload permissions
- [ ] Check file input name is "featured_image"

### Issue: Session not working

- [ ] Check if sessions are enabled in PHP
- [ ] Check session.save_path is writable
- [ ] Check cookies are enabled in browser
- [ ] Clear browser cookies and try again

### Issue: Blank page

- [ ] Check PHP error logs
- [ ] Enable error display in PHP:
  ```php
  ini_set('display_errors', 1);
  error_reporting(E_ALL);
  ```
- [ ] Check file paths are correct
- [ ] Check file permissions

## 📊 Configuration Reference

### config.php

```php
define('WP_API_BASE_URL', 'http://localhost/wp-rest-apis/wp-json/');
define('APP_BASE_URL', 'http://localhost/ci4-wordpress-apis/');
```

### .htaccess

```apache
RewriteBase /ci4-wordpress-apis/
```

### WordPress wp-config.php

```php
define('JWT_AUTH_SECRET_KEY', 'your-secret-key');
define('JWT_AUTH_CORS_ENABLE', true);
```

### WordPress .htaccess

```apache
RewriteCond %{HTTP:Authorization} ^(.*)
RewriteRule ^(.*) - [E=HTTP_AUTHORIZATION:%1]
```

## ✅ Success Indicators

You'll know everything is working when:

1. ✅ Login page loads without errors
2. ✅ Can login with WordPress credentials
3. ✅ Posts list shows all WordPress posts
4. ✅ Can create a new post
5. ✅ Can upload and see featured images
6. ✅ Can edit existing posts
7. ✅ Can delete posts
8. ✅ Flash messages appear correctly
9. ✅ Logout works and redirects to login

## 📞 Need Help?

If you've checked everything and it still doesn't work:

1. Check PHP error logs
2. Check Apache error logs
3. Check browser console for JavaScript errors
4. Review the documentation:
   - SETUP_GUIDE.md
   - README_PHP.md
   - COMPARISON.md

## 🎉 All Done?

If all checkboxes are checked, you're ready to go! 🚀

Visit: `http://localhost/ci4-wordpress-apis/`

---

**Happy coding! 💻**
