<?php
/**
 * Configuration File
 * Update these settings according to your WordPress installation
 */

// WordPress REST API Base URL
define('WP_API_BASE_URL', 'http://localhost/wp-rest-apis/wp-json/');

// Automatically detect the base URL correctly for XAMPP
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$script = $_SERVER['SCRIPT_NAME'];
$base_dir = str_replace('\\', '/', dirname($script));
if ($base_dir !== '/') {
    $base_dir .= '/';
}
$base_url = $protocol . $host . $base_dir;

define('APP_BASE_URL', $base_url);

// Session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
