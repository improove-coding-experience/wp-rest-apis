<?php
/**
 * WordPress REST API Wrapper
 */

/**
 * Make API request to WordPress
 */
function make_api_request($endpoint, $method = 'GET', $data = [], $requires_auth = true) {
    $url = WP_API_BASE_URL . $endpoint;
    
    $headers = [
        'Content-Type: application/json'
    ];
    
    if ($requires_auth && isset($_SESSION['user_token'])) {
        $headers[] = 'Authorization: Bearer ' . $_SESSION['user_token'];
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For local development
    
    switch (strtoupper($method)) {
        case 'POST':
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            break;
        case 'PUT':
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            break;
        case 'DELETE':
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
            break;
        case 'GET':
        default:
            if (!empty($data)) {
                $url .= '?' . http_build_query($data);
                curl_setopt($ch, CURLOPT_URL, $url);
            }
            break;
    }
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return [
            'status' => 500,
            'body' => ['error' => $error]
        ];
    }
    
    return [
        'status' => $http_code,
        'body' => json_decode($response, true)
    ];
}

/**
 * Upload image to WordPress media library
 */
function upload_image_to_wp($file) {
    $url = WP_API_BASE_URL . 'wp/v2/media';
    $token = $_SESSION['user_token'] ?? null;
    
    if (!$token) {
        return ['status' => 401, 'body' => ['error' => 'Unauthorized']];
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['status' => 400, 'body' => ['error' => 'File upload error']];
    }
    
    $file_content = file_get_contents($file['tmp_name']);
    $file_name = basename($file['name']);
    $mime_type = $file['type'];
    
    $headers = [
        'Authorization: Bearer ' . $token,
        'Content-Disposition: attachment; filename="' . $file_name . '"',
        'Content-Type: ' . $mime_type,
        'Cache-Control: no-cache'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $file_content);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return ['status' => 500, 'body' => ['error' => $error]];
    }
    
    return [
        'status' => $http_code,
        'body' => json_decode($response, true)
    ];
}
