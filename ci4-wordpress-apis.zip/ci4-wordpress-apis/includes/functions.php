<?php
/**
 * Helper Functions
 */

/**
 * Redirect to a URL
 */
function redirect($path) {
    $url = APP_BASE_URL . $path;
    header("Location: $url");
    exit;
}

/**
 * Get base URL
 */
function base_url($path = '') {
    return APP_BASE_URL . $path;
}

/**
 * Get site URL (alias for base_url)
 */
function site_url($path = '') {
    return base_url($path);
}

/**
 * Check if user is authenticated
 */
function require_auth() {
    if (!isset($_SESSION['user_token'])) {
        redirect('login');
    }
}

/**
 * Get session flash message
 */
function get_flash($key) {
    if (isset($_SESSION['flash'][$key])) {
        $message = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $message;
    }
    return null;
}

/**
 * Set session flash message
 */
function set_flash($key, $message) {
    $_SESSION['flash'][$key] = $message;
}

/**
 * Sanitize output
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Check if session has flash message
 */
function has_flash($key) {
    return isset($_SESSION['flash'][$key]);
}
