<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | WP Content Manager</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css'); ?>?v=<?php echo time(); ?>">
</head>
<body>

    <nav class="top-nav">
        <div class="logo">
            <div class="logo-icon">W</div>
            <span>WP Admin Rest API Dashboard</span>
        </div>
        <div class="nav-right">
            <a href="<?php echo base_url('logout'); ?>" class="btn btn-secondary btn-sm">Sign Out</a>
        </div>
    </nav>

    <main class="main-content">
        <header class="page-header">
            <div>
                <h1 class="page-title">Manage Content</h1>
                <p class="page-desc">Easily create, update, and manage your WordPress articles.</p>
            </div>
            <a href="<?php echo base_url('create-post'); ?>" class="btn btn-primary">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd" /></svg>
                Create New Post
            </a>
        </header>

        <?php if (has_flash('success')): ?>
            <div class="alert alert-success"><?php echo e(get_flash('success')); ?></div>
        <?php endif; ?>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th width="40">ID</th>
                        <th width="80">Image</th>
                        <th>Post Title</th>
                        <th>Slug</th>
                        <th>Status</th>
                        <th style="text-align: right;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($posts)): ?>
                        <?php foreach ($posts as $post): ?>
                    <tr>
                        <td style="color: var(--text-muted); font-weight: 500; font-family: monospace;"><?php echo e($post['id']); ?></td>
                        <td>
                            <?php 
                                $imageUrl = '';
                                if (isset($post['_embedded']['wp:featuredmedia'][0]['source_url'])) {
                                    $imageUrl = $post['_embedded']['wp:featuredmedia'][0]['source_url'];
                                }
                            ?>
                            <?php if ($imageUrl): ?>
                                <img src="<?php echo e($imageUrl); ?>" class="thumbnail" alt="">
                            <?php else: ?>
                                <div class="thumbnail" style="display: flex; align-items: center; justify-content: center; font-size: 10px; color: var(--text-muted); background: #f8fafc;">NO IMG</div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="font-weight: 600; color: var(--text-primary); font-size: 1rem;"><?php echo e($post['title']['rendered']); ?></div>
                            <div style="display: flex; align-items: center; gap: 8px; margin-top: 4px;">
                                <span style="font-size: 0.7rem; color: var(--text-muted);">Updated <?php echo date('M d, Y', strtotime($post['modified'] ?? 'now')); ?></span>
                            </div>
                        </td>
                        <td>
                            <span style="font-family: monospace; font-size: 0.8rem; background: #f1f5f9; padding: 2px 6px; border-radius: 4px; color: var(--text-secondary);">
                                <?php echo e($post['slug']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge badge-<?php echo e($post['status']); ?>">
                                <?php echo e($post['status']); ?>
                            </span>
                        </td>
                        <td style="text-align: right;">
                            <div style="display: flex; gap: 8px; justify-content: flex-end;">
                                <a href="<?php echo site_url('update-post/' . $post['id']); ?>" class="btn btn-secondary btn-sm">Edit</a>
                                <button class="btn btn-danger btn-sm btn-post-delete" data-id="<?php echo e($post['id']); ?>">Delete</button>
                            </div>
                        </td>
                    </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="padding: 4rem; text-align: center; color: var(--text-muted);">No posts discovered yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 3000);

        $('.btn-post-delete').on('click', function() {
            var postId = $(this).data('id');
            if (confirm('Are you sure you want to delete this post?')) {
                var row = $(this).closest('tr');
                $.ajax({
                    url: '<?php echo site_url('delete-post/'); ?>' + postId,
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == 'success') {
                            row.fadeOut(function() { $(this).remove(); });
                        } else {
                            alert('Error: ' + response.message);
                        }
                    }
                });
            }
        });
    });
    </script>
</body>
</html>
