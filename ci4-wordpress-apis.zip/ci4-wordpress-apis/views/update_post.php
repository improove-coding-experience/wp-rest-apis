<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post | Dashboard</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css'); ?>?v=<?php echo time(); ?>">
</head>
<body>

    <nav class="top-nav">
        <div class="logo">
            <div class="logo-icon">W</div>
            <span>WP Admin Dashboard</span>
        </div>
        <div class="nav-right">
            <a href="<?php echo base_url('logout'); ?>" class="btn btn-secondary btn-sm">Sign Out</a>
        </div>
    </nav>

    <main class="main-content">
        <div class="card" style="max-width: 800px; margin: 0 auto;">
            <header style="margin-bottom: 2rem;">
                <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.5rem;">Update Article</h1>
                <p style="color: var(--text-muted); font-size: 0.9rem;">Editing post ID: <span style="font-family: monospace; font-weight: 700; color: var(--text-primary);">#<?php echo e($post_id); ?></span></p>
            </header>
            
            <form method="post" action="<?php echo site_url('update-post/' . $post_id); ?>" enctype="multipart/form-data">

                <div class="form-group">
                    <label for="title">Post Title</label>
                    <input type="text" id="title" name="title" value="<?php echo isset($post_data['title']['raw']) ? e($post_data['title']['raw']) : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="content">Description / Content</label>
                    <textarea id="content" name="content" style="height: 250px; resize: vertical;" required><?php echo isset($post_data['content']['raw']) ? e($post_data['content']['raw']) : ''; ?></textarea>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select id="category" name="category">
                            <option value="">-- Choose Category --</option>
                            <?php if (!empty($categories)): ?>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo e($cat['id']); ?>" <?php echo (isset($post_data['categories']) && in_array($cat['id'], $post_data['categories'])) ? 'selected' : ''; ?>><?php echo e($cat['name']); ?></option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="status">Publication Status</label>
                        <select id="status" name="status" required>
                            <option value="publish" <?php echo isset($post_data['status']) && $post_data['status']=='publish' ? 'selected' : ''; ?>>Published</option>
                            <option value="draft" <?php echo isset($post_data['status']) && $post_data['status']=='draft' ? 'selected' : ''; ?>>Draft</option>
                            <option value="pending" <?php echo isset($post_data['status']) && $post_data['status']=='pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="private" <?php echo isset($post_data['status']) && $post_data['status']=='private' ? 'selected' : ''; ?>>Private</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="featured_image">Featured Image</label>
                    <div style="border: 2px dashed var(--border); padding: 2rem; border-radius: 12px; text-align: center; background: #fafafa;">
                        <?php if (isset($post_data['featured_media']) && $post_data['featured_media'] != 0): ?>
                            <div style="margin-bottom: 1rem; font-size: 0.8rem; color: var(--success); font-weight: 600;">✓ Current Image Attached (ID: <?php echo e($post_data['featured_media']); ?>)</div>
                        <?php endif; ?>
                        <input type="file" id="featured_image" name="featured_image" style="border: none !important; background: transparent !important; padding: 0 !important;">
                        <p style="margin-top: 0.5rem; font-size: 0.8rem; color: var(--text-muted);">Leave empty to keep current image</p>
                    </div>
                </div>

                <div class="form-group">
                    <label for="slug">URL Slug</label>
                    <input type="text" id="slug" name="slug" value="<?php echo isset($post_data['slug']) ? e($post_data['slug']) : ''; ?>" readonly style="background: #f3f4f6 !important; color: var(--text-secondary);">
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--border);">
                    <a href="<?php echo site_url('posts'); ?>" class="btn btn-secondary">Discard Changes</a>
                    <button type="submit" class="btn btn-primary" style="background: var(--success) !important;">Save Changes</button>
                </div>
            </form>
        </div>
    </main>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        (function($) {
            $.fn.convertToSlug = function() {
                var str = $(this).val();
                var slug = str
                    .toLowerCase()
                    .replace(/[^a-z0-9\s-]/g, '')
                    .replace(/\s+/g, '-')
                    .replace(/-+/g, '-');
                return slug;
            };
        })(jQuery);

        $(function(){
            $('#title').on('keyup', function() {
                var slug = $(this).convertToSlug();
                $("#slug").val(slug);
            });
        });
    </script>
</body>
</html>
