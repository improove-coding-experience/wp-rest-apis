<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post | Dashboard</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css'); ?>?v=<?php echo time(); ?>">
</head>
<body>

    <nav class="top-nav">
        <div class="logo">
            <div class="logo-icon">W</div>
            <span>WP Admin Dashboard</span>
        </div>
        <div class="nav-right">
            <a href="<?php echo base_url('logout'); ?>" class="btn btn-secondary btn-sm">Sign Out</a>
        </div>
    </nav>

    <main class="main-content">
        <div class="card" style="max-width: 800px; margin: 0 auto;">
            <header style="margin-bottom: 2rem;">
                <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.5rem;">Create New Article</h1>
                <p style="color: var(--text-muted); font-size: 0.9rem;">Fill in the details below to publish a new post to your WordPress site.</p>
            </header>
            
            <form method="post" action="<?php echo site_url('create-post'); ?>" enctype="multipart/form-data">

                <div class="form-group">
                    <label for="title">Post Title</label>
                    <input type="text" id="title" name="title" placeholder="e.g. My Awesome Post" required>
                </div>

                <div class="form-group">
                    <label for="content">Description / Content</label>
                    <textarea id="content" name="content" style="height: 200px; resize: vertical;" placeholder="Write something amazing..." required></textarea>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select id="category" name="category">
                            <option value="">-- Choose Category --</option>
                            <?php if (!empty($categories)): ?>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo e($cat['id']); ?>"><?php echo e($cat['name']); ?></option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="status">Publication Status</label>
                        <select id="status" name="status" required>
                            <option value="publish">Publish Immediately</option>
                            <option value="draft">Save as Draft</option>
                            <option value="private">Private</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="featured_image">Featured Image</label>
                    <div style="border: 2px dashed var(--border); padding: 2rem; border-radius: 12px; text-align: center; background: #fafafa;">
                        <input type="file" id="featured_image" name="featured_image" style="border: none !important; background: transparent !important; padding: 0 !important;">
                        <p style="margin-top: 0.5rem; font-size: 0.8rem; color: var(--text-muted);">Recommended size: 1200x630px (JPG, PNG)</p>
                    </div>
                </div>

                <div class="form-group">
                    <label for="slug">URL Slug (Auto-generated)</label>
                    <input type="text" id="slug" name="slug" readonly value="" style="background: #f3f4f6 !important; color: var(--text-secondary);">
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 2rem; padding-top: 2rem; border-top: 1px solid var(--border);">
                    <a href="<?php echo site_url('posts'); ?>" class="btn btn-secondary">Cancel & Go Back</a>
                    <button type="submit" class="btn btn-primary">Publish Article</button>
                </div>
            </form>
        </div>
    </main>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        (function($) {
            $.fn.convertToSlug = function() {
                var str = $(this).val();
                var slug = str
                    .toLowerCase()
                    .replace(/[^a-z0-9\s-]/g, '')
                    .replace(/\s+/g, '-')
                    .replace(/-+/g, '-');
                return slug;
            };
        })(jQuery);

        $(function(){
            $('#title').on('keyup', function() {
                var slug = $(this).convertToSlug();
                $("#slug").val(slug);
            });
        });
    </script>
</body>
</html>
