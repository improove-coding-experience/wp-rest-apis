<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Admin Dashboard</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css'); ?>?v=<?php echo time(); ?>">
</head>
<body class="login-screen">

    <div class="login-card">
        <div style="text-align: center; margin-bottom: 2rem;">
            <div class="logo-icon" style="margin: 0 auto 1rem; width: 48px; height: 48px; font-size: 1.5rem;">W</div>
            <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.25rem;">Sign In</h1>
            <p style="color: var(--text-secondary); font-size: 0.875rem;">Access your WordPress dashboard portal</p>
        </div>

        <?php if (has_flash('error')): ?>
            <div class="alert alert-error"><?php echo get_flash('error'); ?></div>
        <?php endif; ?>

        <form method="post" action="<?php echo base_url('login'); ?>">
            <div class="form-group">
                <label for="username">Username or Email</label>
                <input type="text" id="username" name="username" placeholder="admin" required autofocus>
            </div>
            
            <div class="form-group" style="margin-bottom: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                    <label style="margin-bottom: 0;">Password</label>
                    <a href="#" style="font-size: 0.75rem; color: var(--primary); font-weight: 600; text-decoration: none;">Forgot?</a>
                </div>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password" placeholder="••••••••" required>
                    <button type="button" id="togglePassword" class="password-toggle">Show</button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 0.75rem;">Login to Dashboard</button>
        </form>

        <div style="margin-top: 2rem; border-top: 1px solid var(--border); padding-top: 1.5rem; text-align: center;">
            <p style="font-size: 0.75rem; color: var(--text-muted);">
                Secure management via WP-REST JWT Integration
            </p>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(function() {
        // Auto-dismiss alerts
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 3000);

        // Password Reveal Toggle
        $('#togglePassword').on('click', function() {
            const passwordField = $('#password');
            const type = passwordField.attr('type') === 'password' ? 'text' : 'password';
            passwordField.attr('type', type);
            $(this).text(type === 'password' ? 'Show' : 'Hide');
        });
    });
    </script>
</body>
</html>
