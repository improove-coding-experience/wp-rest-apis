# 🚀 Quick Setup Guide - Pure PHP WordPress API App

## ⚡ Quick Start (3 Steps)

### Step 1: Update Configuration

Edit `config.php` and update these two lines:

```php
// Your WordPress REST API URL
define('WP_API_BASE_URL', 'http://localhost/wp-rest-apis/wp-json/');

// Your application URL (where this app is located)
define('APP_BASE_URL', 'http://localhost/ci4-wordpress-apis/');
```

### Step 2: Update .htaccess

Edit `.htaccess` and update the RewriteBase:

```apache
RewriteBase /ci4-wordpress-apis/
```

If your app is in a different folder, change `/ci4-wordpress-apis/` to your folder path.

### Step 3: Access the Application

Open your browser and go to:

```
http://localhost/ci4-wordpress-apis/
```

Login with your WordPress username and password.

## ✅ That's It!

Your pure PHP WordPress API integration is ready to use!

## 📋 Requirements Checklist

- [x] PHP 7.4+ with cURL enabled
- [x] Apache with mod_rewrite enabled
- [x] WordPress with JWT Auth plugin configured
- [x] Updated `config.php` with correct URLs
- [x] Updated `.htaccess` with correct RewriteBase

## 🔧 Testing

1. **Login Test**: Go to `/login` and enter WordPress credentials
2. **List Posts**: After login, you should see all WordPress posts
3. **Create Post**: Click "Create Post" and add a new post
4. **Upload Image**: Try uploading a featured image
5. **Edit Post**: Click "Edit" on any post
6. **Delete Post**: Click "Delete" on any post

## ⚠️ Common Issues

### Can't access any page (404 errors)

- Check if mod_rewrite is enabled in Apache
- Verify `.htaccess` RewriteBase matches your folder

### Login fails

- Verify WordPress JWT plugin is installed and configured
- Check `WP_API_BASE_URL` in `config.php`

### Images won't upload

- Check PHP upload limits in `php.ini`
- Verify WordPress media upload permissions

## 📞 Need Help?

Check the full `README_PHP.md` for detailed documentation.

---

**Enjoy your framework-free PHP application! 🎉**
