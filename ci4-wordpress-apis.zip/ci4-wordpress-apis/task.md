# Task: Integrate WordPress REST API into CI4 App

## Status

- [x] Setup API Helper/Service in BaseController <!-- id: 0 -->
- [x] Implement Login with JWT Token <!-- id: 1 -->
- [x] Implement List Posts (GET) <!-- id: 2 -->
- [x] Implement Create Post (POST) <!-- id: 3 -->
- [x] Implement Update Post (GET single + POST update) <!-- id: 4 -->
- [x] Implement Delete Post (DELETE) <!-- id: 5 -->
