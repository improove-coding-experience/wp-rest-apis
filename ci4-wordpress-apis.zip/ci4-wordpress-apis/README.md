# Pure PHP WordPress REST API Dashboard

A lightweight, professional dashboard built with pure PHP and vanilla CSS that integrates with the WordPress REST API using JWT (JSON Web Token) authentication.

## 🚀 Features

- **Modern Dashboard:** Professional SaaS-style UI built with Plus Jakarta Sans.
- **Full CRUD:** Create, Read, Update, and Delete WordPress posts.
- **Image Support:** Support for uploading featured images to the WP Media Library.
- **Fast & Secure:** No heavy frameworks, uses native PHP sessions and JWT security.

## 🛠️ Setup Instructions

### 1. WordPress Configuration

- Install and activate the **JWT Authentication for WP-API** plugin on your WordPress site.
- Add the following to your `wp-config.php`:
  ```php
  define('JWT_AUTH_SECRET_KEY', 'your-top-secret-key');
  define('JWT_AUTH_CORS_ENABLE', true);
  ```

### 2. Import the Database

- Open **phpMyAdmin**.
- Create a new database named `wp_json_rest_apis`.
- Use the **Import** tab to upload the `database_backup.sql` file included in this repository.

### 3. Application Configuration

- Open `config.php`.
- Update the `WP_API_BASE_URL` to match your WordPress installation:
  ```php
  define('WP_API_BASE_URL', 'http://localhost/your-wordpress-site/wp-json/');
  ```

### 4. Run the App

- Copy the project folder into your XAMPP `htdocs` directory.
- Access it via `http://localhost/ci4-wordpress-apis/`.

## 🎨 Design details

- **Font:** Plus Jakarta Sans
- **Theme:** Slate & Indigo Professional Dashboard
- **Responsive:** Fully optimized for Mobile, Tablet, and Desktop.
