<?php
/**
 * Create Post Handler
 */

$data = [
    'title' => $_POST['title'] ?? '',
    'content' => $_POST['content'] ?? '',
    'status' => $_POST['status'] ?? 'draft',
];

if (!empty($_POST['slug'])) {
    $data['slug'] = $_POST['slug'];
}

// Handle categories
if (!empty($_POST['category'])) {
    $data['categories'] = [$_POST['category']];
}

// Handle Featured Image Upload
if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] === UPLOAD_ERR_OK) {
    $upload_result = upload_image_to_wp($_FILES['featured_image']);
    if ($upload_result['status'] == 201) {
        $data['featured_media'] = $upload_result['body']['id'];
    }
}

// Call API
$result = make_api_request('wp/v2/posts', 'POST', $data);

if ($result['status'] == 201) {
    set_flash('success', 'Post created successfully!');
    redirect('posts');
} else {
    set_flash('error', 'Failed to create post.');
    redirect('create-post');
}
