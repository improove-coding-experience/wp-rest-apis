<?php
/**
 * List Posts Controller
 */

// Fetch posts with embedded data
$response = make_api_request('wp/v2/posts?status=any&per_page=100&_embed');

$posts = [];
if ($response['status'] == 200) {
    $posts = $response['body'];
}

// Load view
require __DIR__ . '/../views/list_posts.php';
