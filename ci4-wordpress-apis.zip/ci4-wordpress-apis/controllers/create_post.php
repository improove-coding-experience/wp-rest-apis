<?php
/**
 * Create Post Controller
 */

// Fetch categories
$response = make_api_request('wp/v2/categories?per_page=100');
$categories = ($response['status'] == 200) ? $response['body'] : [];

// Load view
require __DIR__ . '/../views/create_post.php';
