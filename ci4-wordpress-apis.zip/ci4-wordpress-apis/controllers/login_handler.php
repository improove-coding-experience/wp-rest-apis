<?php
/**
 * Login Handler
 */

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (!$username || !$password) {
    set_flash('error', 'Username and Password are required');
    redirect('login');
}

// Call JWT API
$result = make_api_request('jwt-auth/v1/token', 'POST', [
    'username' => $username,
    'password' => $password
], false);

if ($result['status'] == 200 && isset($result['body']['token'])) {
    // Save token to session
    $_SESSION['user_token'] = $result['body']['token'];
    $_SESSION['user_email'] = $result['body']['user_email'] ?? '';
    $_SESSION['user_display_name'] = $result['body']['user_display_name'] ?? '';
    
    redirect('posts');
} else {
    // Handle error
    $error_msg = $result['body']['message'] ?? 'Invalid Credentials';
    set_flash('error', $error_msg);
    redirect('login');
}
