<?php
/**
 * Update Post Controller
 */

// Fetch single post
$response = make_api_request("wp/v2/posts/{$post_id}?context=edit&_fields=id,title,content,slug,status,categories,featured_media");
$post_data = ($response['status'] == 200) ? $response['body'] : [];

// Fetch categories
$cat_response = make_api_request('wp/v2/categories?per_page=100');
$categories = ($cat_response['status'] == 200) ? $cat_response['body'] : [];

// Load view
require __DIR__ . '/../views/update_post.php';
