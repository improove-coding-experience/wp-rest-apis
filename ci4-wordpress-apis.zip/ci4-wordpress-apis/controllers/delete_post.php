<?php
/**
 * Delete Post Handler
 */

// Call API with force=true to bypass trash
$result = make_api_request("wp/v2/posts/{$post_id}?force=true", 'DELETE');

header('Content-Type: application/json');

if ($result['status'] == 200) {
    echo json_encode(['status' => 'success', 'message' => 'Post deleted successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to delete post']);
}
exit;
