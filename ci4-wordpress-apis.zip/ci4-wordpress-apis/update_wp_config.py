import re

path = r'C:\xampp\htdocs\wp-rest-apis\wp-config.php'
with open(path, 'r') as f:
    content = f.read()

# Replace DB_NAME
new_content = re.sub(r"define\(\s*'DB_NAME',\s*'.*?'\s*\);", "define( 'DB_NAME', 'ci4-wordpress-apis' );", content)

with open(path, 'w') as f:
    f.write(new_content)

print("Updated wp-config.php")
