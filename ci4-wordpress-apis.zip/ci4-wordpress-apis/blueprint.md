# CI4 to WordPress REST API Integration Blueprint

This document outlines the architecture and implementation details for integrating a CodeIgniter 4 frontend with a WordPress backend via REST API.

## 1. Architecture Overview

**Frontend (CI4)** acts as a client dashboard.
**Backend (WordPress)** serves as the headless CMS and database.

```mermaid
graph LR
    User[User Browser] --> CI4[CI4 Application]
    CI4 -- "API Requests (JSON + JWT)" --> WP[WordPress REST API]
    WP -- "JSON Responses" --> CI4
    CI4 -- "Rendered HTML Views" --> User
```

## 2. Core Components

### A. Centralized API Handling (`BaseController.php`)

We extended `BaseController` to handle all external communication.

- **Method**: `makeApiRequest($endpoint, $method, $data, $requiresAuth)`
- **Functionality**:
  - Automatically attaches the `Authorization: Bearer <token>` header.
  - Handles `Content-Type: application/json`.
  - Disables SSL verification (for local dev environments).
  - Returns a standardized array: `['status' => http_code, 'body' => data]`.

### B. Authentication Flow

We use likely `jwt-auth` plugin on WordPress.

1. **User Request**: Submits username/password to `LoginController::authenticateUser`.
2. **API Call**: `POST /jwt-auth/v1/token` with credentials.
3. **Session**: On 200 OK, the returned **JWT Token** is stored in CI4 `session('user_token')`.
4. **Middleware**: All protected Controller methods check `session()->get('user_token')` before proceeding.

## 3. Post Management (CRUD)

| Action     | CI4 Route             | CI4 Method                                | WP API Endpoint                | Method |
| :--------- | :-------------------- | :---------------------------------------- | :----------------------------- | :----- |
| **List**   | `/posts`              | `PostController::listPost`                | `/wp/v2/posts?status=any`      | GET    |
| **Create** | `/submit-create-post` | `PostController::submitPostHandler`       | `/wp/v2/posts`                 | POST   |
| **Read**   | `/update-post/(:num)` | `PostController::updatePost`              | `/wp/v2/posts/{id}`            | GET    |
| **Update** | `/update-post/(:num)` | `PostController::submitUpdatePostHandler` | `/wp/v2/posts/{id}`            | POST   |
| **Delete** | `/delete-post/(:num)` | `PostController::deletePost`              | `/wp/v2/posts/{id}?force=true` | DELETE |

## 4. Key Implementation Details

- **Context 'Edit'**: When fetching a post for updating (`updatePost`), we pass `?context=edit` to WP. This gives us the _raw_ content (e.g., `<!-- wp:paragraph -->`) suitable for the textarea, rather than the rendered HTML.
- **Dynamic Categories**: The Create and Update views dynamically fetch categories from `/wp/v2/categories` to populate the dropdown.
- **Deleted vs Trashed**: The delete function uses `?force=true` to permanently delete the post (`DELETE` method), bypassing the WordPress "Trash" folder.

## 5. File Structure

- `app/Controllers/BaseController.php` (API Helper)
- `app/Controllers/LoginController.php` (Auth Logic)
- `app/Controllers/PostController.php` (CRUD Logic)
- `app/Views/wp/`
  - `list_post_view.php`
  - `create_post_view.php`
  - `update_post_view.php`
