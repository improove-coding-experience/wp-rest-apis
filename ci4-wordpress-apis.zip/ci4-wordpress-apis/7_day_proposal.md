# Accelerated Project Proposal: 7-Day Plan

**Bid Price**: ₹12,500 INR
**Timeline**: 7 Days
**Scope**: Full Website Refresh, GMB Optimization, and Directory Standardization.

## Execution Strategy

To meet the aggressive 7-day deadline, we will run the Listing/GMB work in parallel with the Design/Content work.

### Day 1: Audit & Strategy

- **Morning**: Full audit of GMB, Website, and top 5-10 major directories.
- **Afternoon**: Define "Brand Visuals" (Colors, Fonts, Tone) and get immediate client approval.
- **Output**: Implementation Plan & Style Guide Draft.

### Day 2: Content & GMB Optimization

- **Task A (SEO/Listings)**: Execute GMB optimization (Photos, Services, FAQs) and start directory cleanup.
- **Task B (Content)**: Draft new, tightened copy for the website (Home, About, Services, Contact).
- **Goal**: Have all text content ready for the website refresh.

### Day 3: Website Design Refresh (Draft)

- **Focus**: Design overhaul on the existing domain (using Staging if possible, or maintenance mode at night).
- **Action**: Apply new color palette, typography, and responsive layout adjustments.
- **Deliverable**: Home Page & Service Page visual draft for review.

### Day 4: Website Development & Speed

- **Development**: Build out remaining pages.
- **Optimization**: Compress images, minify CSS/JS for speed.
- **Integration**: Ensure appointment links and GMB maps are correctly embedded.

### Day 5: Review & Refine

- **Client Review**: Walkthrough of the new site and updated GMB profile.
- **Directory Report**: Compile the spreadsheet of updated listings.
- **Fixes**: Address any immediate feedback on design or text.

### Day 6: Final Polish & SEO Checks

- **SEO**: Verify meta tags, heading structure, and local keywords.
- **Testing**: rigoruous mobile testing and form testing.
- **listings**: Final check on directory approvals.

### Day 7: Launch & Handover

- **Go Live**: Push changes to production.
- **Deliverables**: Hand over the Style Guide (PDF) and Directory Report (Spreadsheet).
- **Post-Launch**: Begin the 2-week support period.

## Why this works for ₹12,500

1.  **Focused Scope**: We will focus on the _major_ directories first to ensure the biggest impact quickly.
2.  **Efficiency**: Using a "content-first" approach on Day 2 ensures the design phase (Day 3-4) doesn't get stalled waiting for text.
3.  **Tooling**: Managing GMB and Citations will be done manually but efficiently by targeting the high-authority platforms first.
