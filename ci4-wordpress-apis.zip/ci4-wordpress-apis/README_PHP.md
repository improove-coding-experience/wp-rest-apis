# Pure PHP WordPress API Integration

A simple, framework-free PHP application for managing WordPress posts via REST API.

## 🎯 Features

- ✅ **No Framework Dependencies** - Pure PHP, runs on Apache only
- ✅ **WordPress REST API Integration** - Full CRUD operations for posts
- ✅ **JWT Authentication** - Secure login using WordPress JWT tokens
- ✅ **Image Upload** - Upload featured images to WordPress media library
- ✅ **Clean Routing** - Simple URL routing with .htaccess
- ✅ **Session Management** - Secure session handling
- ✅ **AJAX Delete** - Delete posts without page reload

## 📋 Requirements

- **PHP 7.4+** (with cURL extension enabled)
- **Apache Server** (with mod_rewrite enabled)
- **WordPress** with:
  - REST API enabled
  - JWT Authentication plugin installed and configured

## 🚀 Installation

### 1. WordPress Setup

Install and configure the JWT Authentication plugin on your WordPress site:

```bash
# In your WordPress installation
wp plugin install jwt-authentication-for-wp-rest-api --activate
```

Add to your WordPress `wp-config.php`:

```php
define('JWT_AUTH_SECRET_KEY', 'your-secret-key-here');
define('JWT_AUTH_CORS_ENABLE', true);
```

Add to your WordPress `.htaccess`:

```apache
RewriteEngine On
RewriteCond %{HTTP:Authorization} ^(.*)
RewriteRule ^(.*) - [E=HTTP_AUTHORIZATION:%1]
```

### 2. Application Setup

1. **Clone/Download** this application to your Apache web directory

2. **Configure** the application by editing `config.php`:

```php
// Update these values
define('WP_API_BASE_URL', 'http://your-wordpress-site.com/wp-json/');
define('APP_BASE_URL', 'http://localhost/ci4-wordpress-apis/');
```

3. **Set Permissions** (if on Linux):

```bash
chmod -R 755 /path/to/ci4-wordpress-apis
```

4. **Enable mod_rewrite** in Apache (if not already enabled):

```bash
# On Ubuntu/Debian
sudo a2enmod rewrite
sudo systemctl restart apache2
```

## 📁 Project Structure

```
ci4-wordpress-apis/
├── index.php              # Main entry point & router
├── config.php             # Configuration file
├── .htaccess             # Apache rewrite rules
│
├── includes/
│   ├── functions.php     # Helper functions
│   └── api.php          # WordPress API wrapper
│
├── controllers/
│   ├── login_handler.php
│   ├── list_posts.php
│   ├── create_post.php
│   ├── create_post_handler.php
│   ├── update_post.php
│   ├── update_post_handler.php
│   └── delete_post.php
│
├── views/
│   ├── login.php
│   ├── list_posts.php
│   ├── create_post.php
│   └── update_post.php
│
└── assets/
    └── style.css         # Styles
```

## 🔧 Usage

### Access the Application

1. Navigate to: `http://localhost/ci4-wordpress-apis/`
2. Login with your WordPress credentials
3. Manage posts (Create, Read, Update, Delete)

### Available Routes

- `GET /` or `/login` - Login page
- `POST /login` - Authenticate user
- `GET /posts` - List all posts
- `GET /create-post` - Show create post form
- `POST /create-post` - Submit new post
- `GET /update-post/{id}` - Show edit post form
- `POST /update-post/{id}` - Update existing post
- `GET /delete-post/{id}` - Delete post (AJAX)
- `GET /logout` - Logout

## 🔐 Security Features

- Session-based authentication
- CSRF protection via session tokens
- HTML output escaping
- Secure password handling (via WordPress)
- HTTP-only cookies

## 🛠️ Customization

### Change WordPress URL

Edit `config.php`:

```php
define('WP_API_BASE_URL', 'http://your-new-wordpress-url.com/wp-json/');
```

### Change Application URL

Edit `config.php`:

```php
define('APP_BASE_URL', 'http://your-domain.com/your-app-path/');
```

Also update `.htaccess`:

```apache
RewriteBase /your-app-path/
```

### Modify Styles

Edit `assets/style.css` to customize the appearance.

## 📝 API Functions

### Helper Functions (`includes/functions.php`)

- `redirect($path)` - Redirect to URL
- `base_url($path)` - Get base URL
- `require_auth()` - Check authentication
- `set_flash($key, $message)` - Set flash message
- `get_flash($key)` - Get flash message
- `e($string)` - Escape HTML output

### API Functions (`includes/api.php`)

- `make_api_request($endpoint, $method, $data, $requires_auth)` - Make API request
- `upload_image_to_wp($file)` - Upload image to WordPress

## 🐛 Troubleshooting

### Issue: 404 on all routes

**Solution:** Enable mod_rewrite in Apache and ensure `.htaccess` is being read.

```bash
# Check if mod_rewrite is enabled
apache2ctl -M | grep rewrite

# Enable it if not
sudo a2enmod rewrite
sudo systemctl restart apache2
```

### Issue: "Unauthorized" error

**Solution:** Check WordPress JWT configuration in `wp-config.php` and `.htaccess`.

### Issue: Images not uploading

**Solution:**

1. Check PHP upload limits in `php.ini`:

```ini
upload_max_filesize = 10M
post_max_size = 10M
```

2. Ensure WordPress media upload permissions are correct

### Issue: Session not persisting

**Solution:** Check PHP session configuration and ensure cookies are enabled in browser.

## 🔄 Migration from CodeIgniter 4

This application replaces the CodeIgniter 4 framework with pure PHP. All functionality remains the same:

- ✅ Login/Authentication
- ✅ List Posts
- ✅ Create Posts
- ✅ Update Posts
- ✅ Delete Posts
- ✅ Featured Image Upload

## 📄 License

This project is open-source and available under the MIT License.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📞 Support

For issues or questions, please open an issue on the repository.

---

**Note:** This is a pure PHP application with no framework dependencies. It requires only Apache and PHP to run.
