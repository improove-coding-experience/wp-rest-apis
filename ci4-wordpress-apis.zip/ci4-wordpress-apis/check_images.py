import json
with open('temp_post.json', 'r') as f:
    data = json.load(f)
for post in data:
    print(f"Post ID: {post.get('id')}")
    embedded = post.get('_embedded', {})
    media = embedded.get('wp:featuredmedia', [])
    if media:
        print(f"Source URL: {media[0].get('source_url')}")
    else:
        print("No featured media found in _embedded")
